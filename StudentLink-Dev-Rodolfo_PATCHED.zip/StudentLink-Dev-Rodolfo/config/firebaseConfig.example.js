// Firebase web config template (commit this file)
// Copy to: public/js/firebaseConfig.js (DO NOT COMMIT that file)

export const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "student-platform-a5328.firebaseapp.com",
  projectId: "student-platform-a5328",
  storageBucket: "student-platform-a5328.firebasestorage.app",
  messagingSenderId: "470217676616",
  appId: "PASTE_APP_ID",
  measurementId: "PASTE_MEASUREMENT_ID" // optional
};
