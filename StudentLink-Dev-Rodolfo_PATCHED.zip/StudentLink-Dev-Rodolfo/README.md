# Student Link

A web-based social platform for students

Utilizes a PHP software stack alongside Firebase 