<?php
header("location: application/userlogin.html"); // redirect to sign in page
?>