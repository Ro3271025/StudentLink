<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Firebase Test</title>
</head>
<body>
  <h1>Firebase Test Page Loaded</h1>
  <p>If you can read this, PHP/HTML is rendering.</p>

  <script type="module">
    import { auth, db } from "./js/firebaseInit.js";
    console.log("Firebase project:", auth.app.options.projectId);
    console.log("Firestore loaded:", !!db);
    document.body.insertAdjacentHTML("beforeend", "<p>✅ JS module executed (check Console)</p>");
  </script>
</body>
</html>
