<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>

<body>

<h2>Dashboard</h2>
<p id="userInfo"></p>
<button id="logoutBtn">Logout</button>

<script type="module">
import { setupDashboard } from "./js/dashboard.js";
setupDashboard();
</script>

</body>
</html>
