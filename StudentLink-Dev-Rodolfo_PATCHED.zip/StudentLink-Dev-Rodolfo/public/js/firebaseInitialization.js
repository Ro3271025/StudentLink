// Backwards-compatible re-export (keep imports working)
// Prefer importing from './firebaseInit.js' going forward.

export { app, auth, db } from "./firebaseInit.js";
